dz_ci = require("dz_ci_filter")--单字模式
core2022 = require("core2022_filter")--自定义字符集过滤
number_translator = require("number")--简易计算、小写转大写
